
layout = RBA::Layout.new
layout.read($input)
layout.write($output)